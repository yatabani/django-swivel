Intro
=====
This project aims at bridging the gap between django and single page applications (SPA).
